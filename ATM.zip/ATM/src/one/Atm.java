package one;

import java.util.Scanner;

public class Atm {

	public static void main(String[] args) {

		int balance = 75000, withdraw, deposit;

		Scanner sc = new Scanner(System.in);

		while (true) {
			System.out.println("ATM");
			System.out.println("Plz Choose 1 for Withdraw");
			System.out.println("Plz Choose 2 for Deposit");
			System.out.println("Plz Choose 3 for Check Balance");
			System.out.println("Plz Choose 4 for EXIT");
			System.out.print("Choose the operation you want to perform:");

			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				System.out.print("Enter money to be withdrawn:");

				withdraw = sc.nextInt();

				if (balance >= withdraw) {
					balance = balance - withdraw;
					System.out.println("Please collect your money");
				} else {
					System.out.println("Insufficient Balance");
				}
				System.out.println("");
				break;

			case 2:

				System.out.print("Enter money to be deposited:");
				deposit = sc.nextInt();

				// money will be added
				balance = balance + deposit;
				System.out.println("Your Money has been successfully deposited");
				System.out.println("");
				break;

			case 3:
				// total amount of the user
				System.out.println("Balance : " + balance);
				System.out.println("");
				break;

			case 4:
				// exit from the menu
				System.exit(0);
			}
		}
	}
}
